from django.contrib import admin
from pipeline.models import Frontpage, Pipeline

admin.site.register(Frontpage)
admin.site.register(Pipeline)