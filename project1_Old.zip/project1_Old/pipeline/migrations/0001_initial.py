# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Pipeline',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('project_code_text', models.CharField(max_length=200)),
                ('project_name', models.CharField(max_length=200)),
                ('start_date', models.DateTimeField(verbose_name=b'start_date')),
                ('end_date', models.DateTimeField(verbose_name=b'end_date')),
                ('project_leader', models.CharField(max_length=200)),
                ('project_staffing', models.CharField(max_length=200)),
                ('project_status', models.CharField(max_length=200)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
    ]
